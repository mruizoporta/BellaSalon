let lenguaje=1;

function idioma(opt){
    lenguaje = opt;  
}