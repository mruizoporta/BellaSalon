	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">           
            <li>
				<a href="{{ url('/home') }}">
					<i class="glyphicon glyphicon-signal"></i>
					<span class="lbl">Dashboard </span>
				</a>
			</li>
	        <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-user"></i>
	                <span class="lbl">Seguridad</span>
	            </span>
	            <ul>
					<li><a href="{{ url('/roles') }}"><span class="lbl">Roles</span></a></li>
	                <li><a href="{{ url('/usuarios') }}"><span class="lbl">Usuarios</span></a></li>	                
	            </ul>
	        </li>
	    
            <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-cog"></i>
	                <span class="lbl">Configuracion</span>
	            </span>
	            <ul>
					<a href="{{ url('/empresas') }}"><span class="lbl">Empresas</span></a></li>
	                <li><a href="{{ url('/parametros/1/edit') }}"><span class="lbl">Parametros Generales</span></a></li>	                                     
                    <li><a href="{{ url('/sucursales') }}"><span class="lbl">Sucursales</span></a></li>                    
	            </ul>
	        </li>
	        <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-gift"></i>
	                <span class="lbl">Catálogos </span>
	            </span>
	            <ul>
					<li><a href="{{ url('/cargos') }}"><span class="lbl">Cargos</span></a></li>
	                <li><a href="{{ url('/marcas') }}"><span class="lbl">Marcas</span></a></li>
	                <li><a href="{{ url('/medidas') }}"><span class="lbl">Unidades de medida</span></a></li>
	                <li><a href="{{ url('/categorias') }}"><span class="lbl">Categorias</span></a></li>
					<li><a href="{{ url('/tipossalidas') }}"><span class="lbl">Tipos de salidas</span></a></li>     
					<li><a href="{{ url('/tiposentradas') }}"><span class="lbl">Tipos de entrada</span></a></li>                  
	            </ul>
	        </li>
	        	      
            <li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-tasks"></span>
	                <span class="lbl">Inventario</span>
	            </span>
                    <ul>
						<li><a href="{{ url('/almacenes') }}"><span class="lbl">Almacenes</span></a></li> 
						<li><a href="{{ url('/productos') }}"><span class="lbl">Productos</span></a></li>
						<li><a href="{{ url('/proveedores') }}"><span class="lbl">Proveedores</span></a></li>												  
                        <li><a href="{{ url('/entradas') }}"><span class="lbl">Entradas</span></a></li>
                        <li><a href="{{ url('/salidas') }}"><span class="lbl">Salidas</span></a></li>     
                        <li><a href="{{ url('/existencias') }}"><span class="lbl">Existencia</span></a></li>   
                        <li><a href="{{ url('/kardex') }}"><span class="lbl">Kardex</span></a></li> 						    
                    </ul>	            
	        </li>

			<li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-shopping-cart"></span>
	                <span class="lbl">Facturacion</span>
	            </span>
                    <ul>
                        <li><a href="{{ url('/empleados') }}"><span class="lbl">Empleados</span></a></li>
                        <li><a href="{{ url('/facturas') }}"><span class="lbl">Factura</span></a></li>     
                        <li><a href="{{ url('/candidatos') }}"><span class="lbl">Devoluciones</span></a></li>   
                        <li><a href="{{ url('/cotizaciones') }}"><span class="lbl">Cotizaciones</span></a></li> 
						<li><a href="{{ url('/descuentos') }}"><span class="lbl">Manejo de descuentos</span></a></li>     
                    </ul>	            
	        </li>

			<li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-calendar"></span>
	                <span class="lbl">Ordenes de trabajo</span>
	            </span>
                    <ul>
                        <li><a href="{{ url('/empresas') }}"><span class="lbl">Empresas</span></a></li>
                        <li><a href="{{ url('/ofertas') }}"><span class="lbl">Empleos</span></a></li>     
                        <li><a href="{{ url('/candidatos') }}"><span class="lbl">Candidatos</span></a></li>   
                        <li><a href="{{ url('/solicitudes') }}"><span class="lbl">Solicitudes</span></a></li> 
						<li><a href="bootstrap-datatables.html"><span class="lbl">Contactos</span></a></li>     
                    </ul>	            
	        </li>

			<li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-home"></span>
	                <span class="lbl">Cuentas por pagar</span>
	            </span>
                    <ul>                      
                        <li><a href="{{ url('/ofertas') }}"><span class="lbl">Devoluciones</span></a></li>     
                        <li><a href="{{ url('/candidatos') }}"><span class="lbl">Facturas de compras</span></a></li>   
                        <li><a href="{{ url('/solicitudes') }}"><span class="lbl">Notas de crédito a proveedores</span></a></li> 
						<li><a href="bootstrap-datatables.html"><span class="lbl">Estados de cuenta</span></a></li>     
                    </ul>	            
	        </li>

			<li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-usd"></span>
	                <span class="lbl">Cuentas por cobrar</span>
	            </span>
                    <ul>
                        <li><a href="{{ url('/empresas') }}"><span class="lbl">Clientes</span></a></li>
                        <li><a href="{{ url('/ofertas') }}"><span class="lbl">Notas de crédito</span></a></li>     
                        <li><a href="{{ url('/candidatos') }}"><span class="lbl">Notas de debito</span></a></li>   
                        <li><a href="{{ url('/solicitudes') }}"><span class="lbl">Recibos</span></a></li> 
						<li><a href="bootstrap-datatables.html"><span class="lbl">Estados de cuenta</span></a></li>     
                    </ul>	            
	        </li>

			<li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-book"></span>
	                <span class="lbl">Contabilidad</span>
	            </span>
                    <ul>
						<li><a href="{{ url('/empresas') }}"><span class="lbl">Parametros contables</span></a></li> 
                        <li><a href="{{ url('/empresas') }}"><span class="lbl">Cuentas contables</span></a></li>
                        <li><a href="{{ url('/ofertas') }}"><span class="lbl">Comprobantes</span></a></li>     
                        <li><a href="{{ url('/candidatos') }}"><span class="lbl">Blance General</span></a></li>   
                        <li><a href="{{ url('/solicitudes') }}"><span class="lbl">Estado de resultados</span></a></li> 
						<li><a href="bootstrap-datatables.html"><span class="lbl">Balanza de comprobacion</span></a></li>     
                    </ul>	            
	        </li>
	    
	    </ul>
	
	</nav><!--.side-menu-->