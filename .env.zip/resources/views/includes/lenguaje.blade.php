<div class="dropdown dropdown-lang">
    <button class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="flag-icon flag-icon-us"></span>
    </button>
    <div class="dropdown-menu dropdown-menu-right">
        <div class="dropdown-menu-col">	                             
            <a class="dropdown-item" href="#"><span class="flag-icon flag-icon-es"></span>Español</a>	                                
        </div>
        
    </div>
</div>