<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleos | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>
    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> >
    </header>
    <!-- Body -->
    <div class="edu-hero-job px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 fw-bold">Ofertas de Trabajo</h1>
    </div>
    <div class="container">
        <div class="row row-cols-1 row-cols-md-2 mb-5 g-5">
            <div class="col col-md-4 col-lg-3">
                <div class="accordion edu-filter" id="EduFilter">
                    <div class="accordion-item">
                      <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#filterType" aria-expanded="true" aria-controls="collapseOne">
                          Filtro
                        </button>
                      </h2>
                      <div id="filterType" class="accordion-collapse collapse show" data-bs-parent="#EduFilter">
                        <div class="accordion-body">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckSchools">
                                <label class="form-check-label" for="flexCheckSchools">
                                    Schools
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckPreschool">
                                <label class="form-check-label" for="flexCheckPreschool">
                                    Preschool & Early Childhood
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckPrimary">
                                <label class="form-check-label" for="flexCheckPrimary">
                                    Primary School
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckSecondary">
                                <label class="form-check-label" for="flexCheckSecondary">
                                    Secondary School
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckUniver">
                                <label class="form-check-label" for="flexCheckUniver">
                                    University & Colleges
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckHigher">
                                <label class="form-check-label" for="flexCheckHigher">
                                    Higher Education
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckAdmin">
                                <label class="form-check-label" for="flexCheckAdmin">
                                    Administrative Position
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckPosition">
                                <label class="form-check-label" for="flexCheckPosition">
                                    Faculty Position
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckExecu">
                                <label class="form-check-label" for="flexCheckExecu">
                                    Executive
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckRecruitment">
                                <label class="form-check-label" for="flexCheckRecruitment">
                                    Temporary & Short-term recruitment
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckGraduate">
                                <label class="form-check-label" for="flexCheckGraduate">
                                    Students & Recent graduates
                                </label>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
            </div>
            <div class="col col-md-8 col-lg-9">
                <div class="edu-content-info mb-4">
                    <div class="edu-card-job card">
                        <div class="card-body">
                            <small class="float-md-end fw-semibold">Hace 4 dias</small>
                            <h5 class="card-title edu-title">Director de Asuntos Académicos</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Administrative Position </h6>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-pointer.png" alt="ubicacion"/> España</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-modalidad.png" alt="modalidad"/> Tiempo completo/remoto</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-company.png" alt="empresa"/> Launchpad Technologies Inc</a>
                            <hr>
                            <p class="card-text">Recognized as one of Canada’s fastest-growing companies, Launchpad provides next-generation integration platform capabilities for connecting and managing.</p>
                            <div class="row text-center">
                                <div class="col-12 col-sm-6">
                                    <a href="empleos-detalle.html" class="btn btn-primary mb-3 mb-md-0 edu-btn-yellow w-100 card-link">Aplicar ya</a>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <a href="#" class="btn btn-primary edu-btn-green w-100 scard-link">Compartir</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="edu-card-job card">
                        <div class="card-body">
                            <small class="float-md-end fw-semibold">Hace 4 dias</small>
                            <h5 class="card-title edu-title">Director de Asuntos Académicos</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Administrative Position </h6>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-pointer.png" alt="ubicacion"/> España</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-modalidad.png" alt="modalidad"/> Tiempo completo/remoto</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-company.png" alt="empresa"/> Launchpad Technologies Inc</a>
                            <hr>
                            <p class="card-text">Recognized as one of Canada’s fastest-growing companies, Launchpad provides next-generation integration platform capabilities for connecting and managing.</p>
                            <div class="row text-center">
                                <div class="col-12 col-sm-6">
                                    <a href="empleos-detalle.html" class="btn btn-primary mb-3 mb-md-0 edu-btn-yellow w-100 card-link">Aplicar ya</a>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <a href="#" class="btn btn-primary edu-btn-green w-100 scard-link">Compartir</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="edu-card-job card">
                        <div class="card-body">
                            <small class="float-md-end fw-semibold">Hace 4 dias</small>
                            <h5 class="card-title edu-title">Director de Asuntos Académicos</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Administrative Position </h6>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-pointer.png" alt="ubicacion"/> España</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-modalidad.png" alt="modalidad"/> Tiempo completo/remoto</a>
                            <a href="#" class="link-underline link-underline-opacity-0 me-2"><img src="./img/web/ico-edu-company.png" alt="empresa"/> Launchpad Technologies Inc</a>
                            <hr>
                            <p class="card-text">Recognized as one of Canada’s fastest-growing companies, Launchpad provides next-generation integration platform capabilities for connecting and managing.</p>
                            <div class="row text-center">
                                <div class="col-12 col-sm-6">
                                    <a href="empleos-detalle.html" class="btn btn-primary mb-3 mb-md-0 edu-btn-yellow w-100 card-link">Aplicar ya</a>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <a href="#" class="btn btn-primary edu-btn-green w-100 scard-link">Compartir</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <nav aria-label="edu-page navigation">
                    <ul class="edu-pagination pagination">
                      <li class="page-item">
                        <a class="page-link" href="#" aria-label="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                      </li>
                      <li class="page-item active"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item">
                        <a class="page-link" href="#" aria-label="Next">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                      </li>
                    </ul>
                  </nav>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- MODAL -->
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
    </div>
    <script src="../js/web/popper.min.js"></script>
    <script src="../js/web/bootstrap.min.js"></script>
    <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/empleos/index.blade.php ENDPATH**/ ?>