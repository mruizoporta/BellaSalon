

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-book"></span> Editar candidato</h5>          
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/candidatos')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
		<div class="box-typical box-typical-padding">
      <form action="<?php echo e(url('/candidatos/'.$candidato->id)); ?>" method="POST"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <fieldset class="form-group">
                <label class="form-label" for="nombrecompleto"> Nombre completo </label>
                <input type="text" name="nombrecompleto" class="form-control" value="<?php echo e($candidato->nombrecompleto); ?>" require> </input>
            </fieldset>

          <fieldset class="form-group">
              <label class="form-label" for="DNI"> Número DNI o Pasaporte </label>
              <input type="text" name="DNI" class="form-control" value="<?php echo e($candidato->DNI); ?>" require> </input>
          </fieldset>
            

            <fieldset class="form-group">                
                <label class="form-label" for="nombrepais">Pais</label>
                <select class="form-control" name="pais_id">
                  <option value=""> --Seleccione el pais--</option>
                  <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($pais -> id); ?>"
                    <?php if($pais->id === $candidato->pais_id): ?>
                            selected
                      <?php endif; ?>
                    > <?php echo e($pais -> nombre); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </select>
            </fieldset>

            <fieldset class="form-group">
							<label class="form-label" for="puesto_actual">Puesto actual</label>             
              <input type="text" name="puesto_actual" class="form-control" value="<?php echo e($candidato->puesto_actual); ?>" require> </input>
            </fieldset>

            <fieldset class="form-group">
							<label class="form-label" for="correo">Correo electrónico profesional</label>
							<input type="email" class="form-control" name="correo" placeholder="Enter email" value="<?php echo e($candidato->correo); ?>">
						</fieldset>

            <fieldset class="form-group">
              <label for="phone"> Telefono / Movil </label>
              <input type="text" name="telefono" class="form-control"  value="<?php echo e($candidato->telefono); ?>"> </input>
            </fieldset>

            <fieldset class="form-group">                
              <label class="form-label" for="lblcategoria">Categoría</label>
              <select class="form-control" name="categoria_id">
                <option value=""> --Seleccione la categoría--</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria -> id); ?>"
                  <?php if($categoria->id === $candidato->categoria_id): ?>
                          selected
                    <?php endif; ?>
                  > <?php echo e($categoria -> nombre); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              </select>
          </fieldset>

          <fieldset class="form-group ">            
            <label for="lblLinkedin2">
              www.linkedin.com/in/  <img src="<?php echo e(asset('img/edu-linkedin-y.png')); ?>" alt="Educator"/> 
            </label> 
            <input type="linkedin" class="form-control" name="linkedin" placeholder="Linkedin" value="<?php echo e(old('correo')); ?>">
   
          </fieldset>
          
            <div  class="form-group">
            <label for="phone"> ¿Cuales son sus intereses laborales? </label>
            <textarea rows="5"  name="intereses"  class="form-control" ><?php echo e($candidato->intereses); ?></textarea>          
          </div >

          
          <fieldset class="form-group">
            <div class="mb-3 edu-form-input">
              <label for="cvCandidate" class="form-label">Modificar curriculum</label>
              <input type="file" class="form-control" name="cv" id="cv" accept=".doc,.docx, .pdf">
          </div>
       
          </fieldset>
            <button type="submit" class="btn btn-sm btn-success" > Guardar candidato</button>
            <br>
            <br>
        </form>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.caret.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.tag-editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/candidatos/edit.blade.php ENDPATH**/ ?>