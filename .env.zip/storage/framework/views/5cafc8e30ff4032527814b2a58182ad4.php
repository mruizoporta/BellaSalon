

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-book"></span> Editar empresa</h5>          
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/empresas')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
		<div class="box-typical box-typical-padding">
      <form action="<?php echo e(url('/empresas/'.$empresa->id)); ?>" method="POST"> 
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <fieldset class="form-group">
                <label class="form-label" for="name"> Nombre </label>
                <input type="text" name="nombre" class="form-control" value="<?php echo e($empresa->nombre); ?>" require> </input>
            </fieldset>

            <fieldset class="form-group">                
                <label class="form-label" for="nombrepais">Pais</label>
                <select class="form-control" name="paises_id">
                  <option value=""> --Seleccione el pais--</option>
                  <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($pais -> id); ?>"
                    <?php if($pais->id === $empresa->paises_id): ?>
                            selected
                      <?php endif; ?>
                    > <?php echo e($pais -> nombre); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </select>
            </fieldset>

            <fieldset class="form-group">
							<label class="form-label" for="nombrecontacto">Nombre del contacto</label>             
              <input type="text" name="nombrecontacto" class="form-control" value="<?php echo e($empresa->nombrecontacto); ?>" require> </input>
            </fieldset>

            <fieldset class="form-group">
							<label class="form-label" for="exampleInputEmail1">Correo electrónico</label>
							<input type="email" class="form-control" name="correocontacto" placeholder="Enter email" value="<?php echo e($empresa->correocontacto); ?>">
						</fieldset>

            <fieldset class="form-group">
              <label for="phone"> Telefono / Movil </label>
              <input type="text" name="telefonocontacto" class="form-control"  value="<?php echo e($empresa->telefonocontacto); ?>"> </input>
            </fieldset>

            <button type="submit" class="btn btn-sm btn-success" > Guardar empresa</button>
            <br>
            <br>
        </form>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.caret.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.tag-editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/empresas/edit.blade.php ENDPATH**/ ?>