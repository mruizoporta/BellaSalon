<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Educators</title>

	<link href="<?php echo e(asset('img/favicon-edu.png')); ?>" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="<?php echo e(asset('img/favicon-edu.png')); ?>" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="<?php echo e(asset('img/favicon-edu.png')); ?>" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="<?php echo e(asset('img/favicon-edu.png')); ?>" rel="apple-touch-icon" type="image/png">
	<link href="<?php echo e(asset('img/favicon-edu.png')); ?>" rel="icon" type="image/png">
	<link href="<?php echo e(asset('img/favicon.ico')); ?>" rel="shortcut icon">
	
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/lobipanel/lobipanel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/lobipanel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/jqueryui/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/widgets.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/separate/main.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/tags_editor.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/bootstrap-select/bootstrap-select.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/select2.min.css')); ?>">  
	
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/summernote/summernote.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/editor.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">

</head>
<body class="with-side-menu control-panel control-panel-compact">

	<header class="site-header">
	    <div class="container-fluid">
	
	        <a href="#" class="site-logo">
	            <img class="logo-per" src="<?php echo e(asset('img/logo-educator-white.png')); ?>" alt="">	            
	        </a>
	
	        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
	            <span>toggle menu</span>
	        </button>
	
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">	                                 
	
	                 	<?php echo $__env->make('includes.lenguaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo $__env->make('includes.userOptions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
	                 
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	               
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="page-content">
	    <div class="container-fluid">
	       <?php echo $__env->yieldContent('content'); ?>	       
	    </div><!--.container-fluid-->
	</div><!--.page-content-->


	<script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('js/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

	<script src="<?php echo e(asset('js/lib/peity/jquery.peity.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/table-edit/jquery.tabledit.min.js')); ?>"></script>

	<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	
	<?php echo $__env->yieldContent('scripts'); ?>


</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/layouts/panel.blade.php ENDPATH**/ ?>