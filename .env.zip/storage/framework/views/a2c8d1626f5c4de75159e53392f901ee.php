<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Inicio | Educator</title>
        <link href="./css/web/bootstrap.min.css"  rel="stylesheet">
        <link href="./css/web/educator.css" rel="stylesheet">
        <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
        <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>

    </head>
    <body >
        <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
            <i class="fa fa-whatsapp icono"></i>
        </a>

        <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/web/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español" onclick="idioma(1)"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles" onclick="idioma(2)"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
       <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
       
    </header>
    <!-- Body -->
    <div class="edu-hero px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 fw-bold">International Education Recruitment</h1>
        <div class="col col-lg-6 mx-auto">
            <p class="text-white lead mb-4">En Educcators, ofrecemos un servicio especializado en la contratación de personal educativo de todos los niveles</p>
            <p class="text-white lead mb-4">Nos dedicamos a brindar apoyo tanto a aquellos que desean avanzar en su carrera profesional dentro del sector, como a las instituciones que buscan atraer y retener al mejor talento.</p>
            <p class="text-white lead mb-4">¡Únete a Educcators hoy mismo y descubre todas las oportunidades que tenemos para ti!</p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center"> 
            <button type="button" class="btn btn-primary btn-lg px-4 gap-3 edu-btn-yellow">Vacancies</button>
            <button type="button" class="btn btn-outline-secondary btn-lg btn-outline-edu-white px-4">Register</button>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row my-5 g-5 align-items-center">
            <div class="col-md-6 col-lg-6">
                <h2 class="edu-title">Nuestra historia</h2>
                <p>Con más de 20 años de experiencia profesional en entornos internacionales y una sólida trayectoria en el sector educativo, contamos con amplia experiencia trabajando en colegios internacionales, universidades e instituciones de posgrado. Esto nos ha brindado una perspectiva única y una comprensión profunda del ámbito educativo.</p>
                <p>Durante nuestra carrera, hemos colaborado con profesionales de primer nivel, lo que nos ha permitido cultivar una amplia red de expertos a nivel global. Nuestro objetivo es aprovechar esta experiencia para brindar apoyo y valiosa información a nuestros clientes y socios que trabajan en la industria de la educación.</p>
            </div>
            <div class="col-md-6 col-lg-6">
                <img src="./img/web/edul-history.png" class="img-fluid mx-auto d-block" alt="Educator historia">
            </div>
        </div>
    </div>
    <div class="edu-features py-5">
        <div class="container">
            <div class="row g-5 text-center">
                <div class="col-sm-12">
                    <h2 class="text-white">Sectores especializados</h2>
                    <p class="text-white pb-5">Trabajamos en colaboración con diversos sectores especializados.</p>
                </div>
            </div>
            <div class="row row-cols-1 g-5 justify-content-center text-center">
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-schools d-block m-auto"></div>
                        <h6 class="my-3">Schools</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-primary_schools d-block m-auto"></div>
                        <h6 class="my-3">Early Childhood & Primary School</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-u d-block m-auto"></div>
                        <h6 class="my-3">University & Colleges</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-h-edu d-block m-auto"></div>
                        <h6 class="my-3">Higher Education</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-business d-block m-auto"></div>
                        <h6 class="my-3">Business Languages Coach</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-speaker d-block m-auto"></div>
                        <h6 class="my-3">Speakers</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container py-5">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12">
                <h2 class="edu-title text-center">Cómo trabajamos</h2>
            </div>
        </div>
        <div class="edu-type-job row row-cols-1 justify-content-center pb-md-5">
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                      <img src="./img/web/icon-enfoque.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Nuestro Enfoque</h5>
                      <p class="card-text">Contamos con una amplia experiencia en la búsqueda de personal en todos los sectores de la educación.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-expe.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Experiencia y especialización</h5>
                      <p class="card-text">Nos avalan años de experiencia trabajando y asesorando a profesionales de la enseñanza.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-candidato.png" class="img-fluid d-block mb-4" alt="Trabajos">
                        <h5 class="card-title edu-title">Encuentra al candidato idóneo</h5>
                        <p class="card-text">Todos nuestros candidatos son cuidadosamente examinados y asignados a las ofertas.</p>
                        <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="edu-type-job row row-cols-1 justify-content-center">
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-necesidad.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Nos adaptamos a tus necesidades</h5>
                      <p class="card-text">Ofrecemos una amplia variedad de opciones para satisfacer a nuestros clientes</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-presupuesto.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Diseñamos presupuestos a la medida de tus exigencias.</h5>
                      <p class="card-text">Entendemos que el presupuesto es un factor importante para cualquier organización.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
        </div>
    </div>
    <div class="edu-clientes py-5">
        <div class="container">
            <div class="row g-5 text-center mb-4">
                <div class="col">
                    <h2 class="edu-title">Nuestros clientes</h2>
                    <p>Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                </div>
            </div>
            <div class="row row-cols-2 row-cols-sm-6 g-5 text-center justify-content-center align-items-center">
                <div class="col">
                    <img src="./img/web/LOGO-UNIVERSITY.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/web/IE_Business_School_logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/web/logo-aleman-collage.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/web/xPAC-logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/web/Esade_logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
            </div>
        </div>
    </div>
    <div class="edu-testimonial">
        <div id="carouselTestimonialEdu" class="carousel slide">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="./img/web/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/web/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./img/web/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/web/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./img/web/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/web/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselTestimonialEdu" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselTestimonialEdu" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
    </div>

    <!-- Footer -->
  <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- MODAL -->
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
    </div>
    <script src="../js/web/popper.min.js"></script>
    <script src="../js/web/bootstrap.min.js"></script>
    <script src="../js/web/util.js"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\postulaciones\resources\views/index.blade.php ENDPATH**/ ?>