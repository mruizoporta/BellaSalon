<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>
    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/web/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </header>
    <!-- Body -->
    <div class="edu-hero-trabajamos pt-5">
        <div class="container">
            <div class="row row-cols-1 g-5 justify-content-center text-center">
                <div class="col-12 col-md-8">
                    <h2 class="text-white">Trabajamos en colaboración con diversos sectores especializados.</h2>
                    <p class="text-white pb-5">Colaboramos con múltiples sectores especializados abarcando una amplia gama de áreas profesionales y geográficas, desde la educación primaria hasta la educación de posgrado.</p>
                </div>
            </div>
            <div class="row row-cols-1 g-5 pb-5 justify-content-center text-center">
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-schools d-block m-auto"></div>
                        <h6 class="my-3">Schools</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-primary_schools d-block m-auto"></div>
                        <h6 class="my-3">Early Childhood & Primary School</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-u d-block m-auto"></div>
                        <h6 class="my-3">University & Colleges</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-h-edu d-block m-auto"></div>
                        <h6 class="my-3">Higher Education</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-business d-block m-auto"></div>
                        <h6 class="my-3">Business Languages Coach</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-speaker d-block m-auto"></div>
                        <h6 class="my-3">Speakers</h6>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center pb-5">
                <div class="col-md-12">
                    <h2 class="text-white text-center">Cómo trabajamos</h2>
                </div>
            </div>
            <div class="edu-type-job row row-cols-1 justify-content-center">
                <div class="col col-md-12 col-lg-4">
                    <div class="card edu-card">
                        <div class="card-body">
                          <img src="./img/web/icon-enfoque.png" class="img-fluid d-block mb-4" alt="Trabajos">
                          <h5 class="card-title edu-title">Nuestro Enfoque</h5>
                          <p class="card-text">Contamos con una amplia experiencia en la búsqueda de personal en todos los sectores de la educación. Nos enorgullece colocar a las personas adecuadas en los puestos correctos, proporcionando un mayor valor tanto al cliente como al candidato. Nuestra misión es alcanzar las tasas de retención más altas de la industria, ofreciendo una calidad de servicio superior a los clientes y candidatos que apoyamos.</p>
                        </div>
                      </div>
                </div>
                <div class="col col-md-12 col-lg-4">
                    <div class="card edu-card">
                        <div class="card-body">
                            <img src="./img/web/icon-expe.png" class="img-fluid d-block mb-4" alt="Trabajos">
                          <h5 class="card-title edu-title">Experiencia y especialización</h5>
                          <p class="card-text">Nos avalan años de experiencia trabajando y asesorando a profesionales de la enseñanza. Continuamos creciendo y actualizando nuestra red y base de datos, lo que nos permite ser selectivos al proporcionar al candidato idóneo. Escucharemos las necesidades y requisitos de nuestro cliente, optimizando el proceso.</p>
                        </div>
                      </div>
                </div>
                <div class="col col-md-12 col-lg-4">
                    <div class="card edu-card">
                        <div class="card-body">
                            <img src="./img/web/icon-candidato.png" class="img-fluid d-block mb-4" alt="Trabajos">
                            <h5 class="card-title edu-title">Encuentra al candidato idóneo</h5>
                            <p class="card-text">Todos nuestros candidatos son cuidadosamente examinados y asignados a las ofertas. Nos esforzamos por simplificar el proceso a través de nuestra plataforma, permitiendo una conexión directa entre nuestra comunidad y las organizaciones interesadas. Simplificamos este proceso ahorrando innumerables horas de trabajo y agilizando la búsqueda de candidatos que se adaptan a sus requisitos.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container edu-position-card py-5">
        <div class="edu-type-job row row-cols-1 justify-content-center">
            <div class="col col-md-12 col-lg-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-necesidad.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Nos adaptamos a tus necesidades</h5>
                      <p class="card-text">Ofrecemos una amplia variedad de opciones para satisfacer a nuestros clientes, desde paquetes básicos de reclutamiento hasta soluciones premium con promoción proactiva y riguroso proceso de selección. Además, facilitamos opciones flexibles de combinación de servicios disponibles. Confía en que encontraremos la opción adecuada para ti.</p>
                    </div>
                  </div>
            </div>
            <div class="col col-md-12 col-lg-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/web/icon-presupuesto.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Diseñamos presupuestos a la medida de tus exigencias.</h5>
                      <p class="card-text">Entendemos que el presupuesto es un factor importante para cualquier organización. Es por eso que ofrecemos precios asequibles y transparentes para que puedas elegir los servicios que se ajusten a tus necesidades y presupuesto. Nuestro modelo de negocio se enfoca en alcanzar resultados concretos para el cliente, generando una relación de confianza y compromiso.</p>
                    </div>
                  </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- MODAL -->
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
    </div>
    <script src="../js/web/popper.min.js"></script>
    <script src="../js/web/bootstrap.min.js"></script>
    <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/trabajamos/index.blade.php ENDPATH**/ ?>