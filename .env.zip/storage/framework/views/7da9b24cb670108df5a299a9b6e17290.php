<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h4 class="text-center edu-title">¿Ya eres usuario?</h4>
                <form class="row g-3 edu-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="edu-form-input col-md-6">
                        <label for="loginEmail" class="form-label">Correo electrónico</label>
                        <input type="email" class="form-control" id="loginEmail" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    </div>
                    <div class="edu-form-input col-md-6">
                        <label for="inputPassword" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="inputPassword"  name="password" required autocomplete="current-password">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary w-100 edu-btn-yellow" >Iniciar sesión</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/auth/login.blade.php ENDPATH**/ ?>