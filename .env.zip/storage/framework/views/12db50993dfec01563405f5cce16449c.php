

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-lock"></span> Edicar rol</h5>
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/cargos')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
		<div class="box-typical box-typical-padding">
        <form action="<?php echo e(url('/roles/'.$rol->id)); ?>" method="POST">       
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name"> Nombre  </label>
                <input type="text" name="nombre" class="form-control" value="<?php echo e($rol->nombre); ?>" require> 
            </div>

            <h5 class="m-t-lg with-border">Permisos a:</h5>
          
            <div class="form-group">
              <div class="" >
                <input type="checkbox" value="" id="seguridad" name="seguridad" <?php if($rol->seguridad): ?> checked <?php endif; ?> />
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-1">Seguridad</label>
              </div>
              <div class="">
                <input type="checkbox" id="configuracion" name="configuracion"<?php if($rol->configuracion): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-2">Configuracion</label>
              </div>
              <div class="">
                <input type="checkbox" id="catalogos" name="catalogos" <?php if($rol->catalogos): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-3">Catalogos</label>
              </div>
              <div class="">
                <input type="checkbox" id="inventario" name="inventario" <?php if($rol->inventario): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Inventario</label>
              </div>
              <div class="">
                <input type="checkbox" id="facturacion" name="facturacion" <?php if($rol->facturacion): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Facturacion</label>
              </div>
              <div class="">
                <input type="checkbox" id="ordentrabajo" name="ordentrabajo" <?php if($rol->ordentrabajo): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Ordenes de trabajo</label>
              </div>
              <div class="">
                <input type="checkbox" id="cuentasporcobrar" name="cuentasporcobrar" <?php if($rol->cuentasporcobrar): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Cuentas por pagar de trabajo</label>
              </div>
              <div class="">
                <input type="checkbox" id="cuentasporpagar" name="cuentasporpagar" <?php if($rol->cuentasporpagar): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Cuentas por cobrar</label>
              </div>
              <div class="">
                <input type="checkbox" id="contabilidad" name="contabilidad" <?php if($rol->contabilidad): ?> checked <?php endif; ?>>
                <label style="display: inline-block !important; font-size:1rem !important; line-height:18px !important; position: relative !important; " for="check-4">Contabilidad</label>
              </div>
            </div>
     

            <button type="submit" class="btn btn-sm btn-success" > Guardar rol</button>
        </form>
        </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartd\resources\views/roles/edit.blade.php ENDPATH**/ ?>