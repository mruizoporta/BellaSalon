
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                <ul class="nav me-auto">
                  <li class="nav-item d-none d-md-block">
                    <b>Phone:</b>
                    <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                    /
                    <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                  </li>
                  <li class="nav-item d-block d-sm-none px-2">
                    <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                  </li>
                  <li class="nav-item d-none d-sm-block px-2">
                    <b>Email:</b>
                    <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                  </li>
                  <li class="nav-item">
                    <a href="#" class="text-white px-2">
                        <img src="./img/edu-linkedin.png" alt="Educator"/>
                    </a>
                  </li>
                </ul>
                <ul class="nav">
                    <li class="nav-item">
                        <a href="#" class="text-white px-2">
                            <img src="./img/edu-es.png" alt="Educator Español" onclick="idioma(1)"/>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="text-white px-2">
                            <img src="./img/edu-en.png" alt="Educator Ingles" onclick="idioma(2)"/>
                        </a>
                    </li>
                </ul>
        </div>
    </div>
</div>
<div class="navbar navbar-expand-lg px-3 py-2 edu-main-nav">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="./img/logo-educator.png" class="img-fluid" alt="Educator"/>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="nav navbar-nav me-auto mb-2 mb-md-0 edu-main-menu">
                <li><a href="index.html" class="nav-link px-2 link-secondary">Inicio</a></li>
                <li><a href="como-trabajamos.html" class="nav-link px-2">Cómo trabajamos</a></li>
                <li><a href="nosotros.html" class="nav-link px-2">Nosotros</a></li>
                <li><a href="empleos.html" class="nav-link px-2">Empleos</a></li>
                <li><a href="contratar.html" class="nav-link px-2">Quiero contratar</a></li>
                <li><a href="registro.html" class="nav-link px-2">Registro</a></li>
                <li><a href="contacto.html" class="nav-link px-2">Contacto</a></li>
            </ul>
            <div class="text-lg-end">
                <button type="button" class="btn btn-primary edu-btn-yellow" data-bs-toggle="modal" data-bs-target="#loginModal">Iniciar sesión</button>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/includes/headerweb.blade.php ENDPATH**/ ?>