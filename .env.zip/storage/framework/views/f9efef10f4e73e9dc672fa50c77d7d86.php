<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiero Contratar | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>
    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </header>
    <!-- Body -->
    <div class="edu-hero-contrato px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 w-75 m-auto fw-bold">¿Tienes una posición difícil de cubrir?</h1>
        <p class="text-white w-75 m-auto lead mb-4">Déjanos ayudarte con cualquier necesidad de contratación que tu institución pueda tener.</p>
    </div>
    <div class="container">
        <div class="row row-cols-1 row-cols-md-2 mb-5 g-5">
            <div class="col col-md-6 col-lg-6">
                <p>Te conectamos con tu público objetivo, lo que permite atraer candidatos de alta calidad para cubrir tus vacantes. Al asociarte con nosotros, tendrás la oportunidad de mostrar las fortalezas de tu institución a una audiencia altamente comprometida y podrás atraer talento de primer nivel. ¡Mejora tu estrategia de reclutamiento hoy con los mejores del negocio!</p>
                <h2 class="edu-title">Ponte en contacto con nosotros para hablar sobre tus necesidades.</h2>
                <p>Te conectamos con tu público objetivo, lo que permite atraer candidatos de alta calidad para cubrir tus vacantes. Al asociarte con nosotros, tendrás la oportunidad de mostrar las fortalezas de tu institución a una audiencia altamente comprometida y podrás atraer talento de primer nivel. ¡Mejora tu estrategia de reclutamiento hoy con los mejores del negocio!</p>
            </div>
            <div class="col col-md-6 col-lg-6">
                <form class="row g-3 edu-form">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="fullnameContract" class="form-label">Nombre y Apellido</label>
                            <input type="text" class="form-control" id="fullnameContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="phoneContract" class="form-label">Numero de contacto</label>
                            <input type="tel" class="form-control" id="phoneContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="mailContract" class="form-label">Correo electrónico</label>
                            <input type="email" class="form-control" id="mailContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="CompanyContract" class="form-label">Empresa</label>
                            <input type="text" class="form-control" id="CompanyContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="positionContract" class="form-label">Puesto de trabajo</label>
                            <input type="text" class="form-control" id="positionContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="mb-3 edu-form-input">
                            <label for="skillContract" class="form-label">Habilidades</label>
                            <input type="text" class="form-control" id="skillContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                        <label for="areaContract" class="form-label">Áreas</label>
                        <input type="text" class="form-control" id="areaContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="modalidadContract" class="form-label">Modalidad</label>
                            <select type="text" class="form-select" id="modalidadContract">
                                <option selected>Seleccionar modalidad</option>
                                <option value="1">Tiempo completo</option>
                                <option value="2">Remoto</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="lengContract" class="form-label">idioma</label>
                            <input type="text" class="form-control" id="lengContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="countryContract" class="form-label">País</label>
                            <input type="email" class="form-control" id="countryContract">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="docContract" class="form-label">Adjuntar descripción del puesto</label>
                            <input type="file" class="form-control" id="docContract" accept=".doc,.docx, .pdf">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3 form-check edu-form-input">
                            <input type="checkbox" class="form-check-input" id="validateTerminos">
                            <label class="form-check-label" for="validateTerminos">Acepto los términos, <b>condiciones y políticas de privacidad de Educcators.</b></label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary edu-btn-yellow">Enviar puesto</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
    </div>
    <script src="../js/web/popper.min.js"></script>
    <script src="../js/web/bootstrap.min.js"></script>
    <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/contratar/index.blade.php ENDPATH**/ ?>