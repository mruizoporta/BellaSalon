

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-th-list"></span> Categorías</h5>
                      </div>
                      <div class="col text-right">
                        <a href="<?php echo e(url('/categorias/create')); ?>" class="btn btn-sm btn-primary edu-btn-yellow " >Nueva categoría</a>
                      </div>
                    </div>
                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                    <div class="table-responsive">
                    <table id="table-categorias" class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th width="1">
                                #
                            </th>
                            <th>Nombre </th>    
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> <?php echo e($categoria-> id); ?> </td>
                                <td> <?php echo e($categoria-> nombre); ?> </td>
                                <td>
                                  <form action="<?php echo e(url('/categorias/'.$categoria->id.'/inactivar')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>                                         
                                      <a href="<?php echo e(url('/categorias/'.$categoria->id.'/edit')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                        <span class="glyphicon glyphicon-pencil"></span>
                                      </a>
                                     
                                      <button type="submit" class="tabledit-edit-button btn btn-sm btn-default">
                                        <span class="glyphicon glyphicon-trash"></span>
                                      </button>

                                    </form>
                                   
                                  </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
        

                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script 
    src="<?php echo e(asset('js/per/categorias.js')); ?>">
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartd\resources\views/categorias/index.blade.php ENDPATH**/ ?>