<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regsitro | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>
    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </header>
    <!-- Body -->
    <div class="edu-hero-registro px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 w-75 m-auto fw-bold">¿Buscas un nuevo puesto, estás pensando en cambiar de trabajo o incluso cambiar de país?</h1>
        <p class="text-white w-75 m-auto lead mb-4">Si te interesa ser candidato, tienes experiencia como docente y quieres crear tu perfil gratis, podemos comenzar el proceso de emparejarte con posibles vacantes que puedan ser de tu interés.</p>
    </div>
    <div class="container">
        <div class="row row-cols-1 mb-5 g-5">
            <div class="col col-md-12 col-lg-12">
                <h4 class="edu-title text-center mb-4">Regístrate con nosotros para ayudarte a encontrar un nuevo trabajo.</h4>
                <form class="row g-3 edu-form">
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="fullnameRegister" class="form-label">Nombre y Apellido</label>
                            <input type="text" class="form-control" id="fullnameRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="positionRegister" class="form-label">Puesto actual</label>
                            <input type="text" class="form-control" id="positionRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                        <label for="passRegister" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="passRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                            <label for="countryRegister" class="form-label">País</label>
                            <input type="text" class="form-control" id="countryRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                            <label for="identRegister" class="form-label">Número DNI o Pasaporte</label>
                            <input type="text" class="form-control" id="identRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="mailRegister" class="form-label">Correo electrónico profesional</label>
                            <input type="email" class="form-control" id="mailRegister">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="catRegister" class="form-label">Categoría</label>
                            <select type="text" class="form-select" id="catRegister">
                                <option selected>Seleccionar categoría</option>
                                <option value="1">Schools</option>
                                <option value="2">Preschool & Early Childhood</option>
                                <option value="3">Primary School</option>
                                <option value="4">Secondary School</option>
                                <option value="5">University & Colleges</option>
                                <option value="6">Higher Education</option>
                                <option value="7">Administrative Position</option>
                                <option value="8">Faculty Position</option>
                                <option value="9">Executive</option>
                                <option value="10">Temporary & Short-term recruitment</option>
                                <option value="11">Students & Recent graduates</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="mb-3 edu-form-input">
                            <label for="interesRegister" class="form-label">¿Cuales son tus intereses laborales?</label>
                            <input type="text" class="form-control" id="interesRegister">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3 form-check edu-form-input">
                            <input type="checkbox" class="form-check-input" id="validateTerminos">
                            <label class="form-check-label" for="validateTerminos">Acepto los términos, <b>condiciones y políticas de privacidad de Educcators.</b></label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary edu-btn-yellow">Registrarse</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
     <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
         <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
     </div>
     <script src="../js/web/popper.min.js"></script>
     <script src="../js/web/bootstrap.min.js"></script>
     <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/registro/index.blade.php ENDPATH**/ ?>