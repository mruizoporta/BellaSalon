

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-user"></span> Candidatos</h5>
                      </div>
                      <div class="col text-right">
                        <a href="<?php echo e(url('/candidatos/create')); ?>" class="btn btn-sm btn-primary edu-btn-yellow " >Nuevo candidato</a>
                      </div>
                    </div>

                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>                 

                    <div class="table-responsive">
                      <div class="bootstrap-table">
                        <div class="fixed-table-toolbar">
                          <div class="pull-left search">
                            <form action="">
                              <div class="form-row">
                                <input type="text" class="form-control" placeholder="Buscar..." name="texto" value=<?php echo e($texto); ?>>
                              </div>
                            </form>
                          </div>
                        </div>
                        <table id="table-candidatos" class="table table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th width="1">
                                    #
                                </th>                                               
                                <th>DNI</th>  
                                <th>Nombre completo</th>    
                                <th>Correo electrónico</th>                            
                                <th>Postulaciones</th>                      
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($candidato-> id); ?> </td>                                
                                    <td> <?php echo e($candidato-> DNI); ?> </td>
                                    <td> <?php echo e($candidato-> nombrecompleto); ?> </td>
                                    <td> <?php echo e($candidato-> correo); ?> </td>  

                                    <td style="text-align:center"> <a href="<?php echo e(url('/candidatos/'.$candidato->id.'/candidatos')); ?>"><?php echo e($candidato-> postulaciones); ?> </a></td>                             
                                    <td>
                                        <form action="<?php echo e(url('/candidatos/'.$candidato->id.'/inactivar')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>    
                                          <a href="<?php echo e(url('/candidatos/'.$candidato->id.'/edit')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-pencil"></span>
                                          </a>
                                        
                                          <button type="submit" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                          </button>

                                          <a href="<?php echo e(url('/candidatos/'.$candidato->id.'/download')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon glyphicon-download-alt"></span>
                                          </a>
                                          <?php if($candidato->linkedin==''): ?>
                                          <a href="https://www.linkedin.com" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span ><i class="fa fa-linkedin fa-fw"></i></i></span>
                                          </a>
                                          <?php else: ?>
                                          <a href="https://www.linkedin.com/in/<?php echo e($candidato->linkedin); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span ><i class="fa fa-linkedin fa-fw"></i></i></span>
                                          </a>
                                          <?php endif; ?>
                                        </form>
                                      
                                      </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>     
                      <div class="pull-right pagination">
                        <ul class="pagination">
                          <?php echo e($candidatos->links()); ?>

                        </ul>
                       
                      </div>  
                  </div>
                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/candidatos/index.blade.php ENDPATH**/ ?>