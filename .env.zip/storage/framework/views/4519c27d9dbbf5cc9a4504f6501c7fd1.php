<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>
    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </header>
    <!-- Body -->
    <div class="edu-hero-contact px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 invisible fw-bold">Contacto</h1>
    </div>
    <div class="container">
        <div class="row row-cols-1 mb-5 g-5">
            <div class="col text-center">
                <h2 class="edu-title">Contacto</h2>
                <p class="lead mb-4">Hablanos de tus necesidades como personal académico o centro.</p>
            </div>
            <div class="col">
                <form class="row g-3 edu-form">
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                            <label for="nameContact" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nameContact">
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                        <label for="mailContact" class="form-label">Correo electrónico</label>
                        <input type="email" class="form-control" id="mailContact">
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-4">
                        <div class="mb-3 edu-form-input">
                            <label for="phoneContact" class="form-label">Teléfono</label>
                            <input type="tel" class="form-control" id="phoneContact">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3 edu-form-input">
                            <label for="MessageContact" class="form-label">Mensaje</label>
                            <textarea class="form-control" id="MessageContact" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-3 form-check edu-form-input">
                            <input type="checkbox" class="form-check-input" id="validateTerminos">
                            <label class="form-check-label" for="validateTerminos">Acepto los términos, <b>condiciones y políticas de privacidad de Educcators.</b></label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary edu-btn-yellow">Enviar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
   <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
       <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
   </div>
   <script src="../js/web/popper.min.js"></script>
   <script src="../js/web/bootstrap.min.js"></script>
   <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/contacto/index.blade.php ENDPATH**/ ?>