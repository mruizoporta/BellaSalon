<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros | Educator</title>
    <link href="./css/web/bootstrap.min.css" rel="stylesheet">
    <link href="./css/web/educator.css" rel="stylesheet">
    <link rel="icon" href="./img/web/favicon-edu.png"type="image/png">
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</head>
<body>
    <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
	    <i class="fa fa-whatsapp icono"></i>
	</a>

    <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/web/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-es.png" alt="Educator Español"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/web/edu-en.png" alt="Educator Ingles"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.menuweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </header>
    <!-- Body -->
    <div class="edu-hero-nosotros px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 invisible fw-bold">Nosotros</h1>
    </div>
    <div class="container">
        <div class="row my-5 g-5 align-items-center">
            <div class="col-md-6 col-lg-6">
                <h2 class="edu-title">Nuestra historia</h2>
                <p>Con más de 20 años de experiencia profesional en entornos internacionales y una sólida trayectoria en el sector educativo, contamos con amplia experiencia trabajando en colegios internacionales, universidades e instituciones de posgrado. Esto nos ha brindado una perspectiva única y una comprensión profunda del ámbito educativo.</p>
                <p>Durante nuestra carrera, hemos colaborado con profesionales de primer nivel, lo que nos ha permitido cultivar una amplia red de expertos a nivel global. Nuestro objetivo es aprovechar esta experiencia para brindar apoyo y valiosa información a nuestros clientes y socios que trabajan en la industria de la educación.</p>
            </div>
            <div class="col-md-6 col-lg-6">
                <img src="./img/web/edul-history.png" class="img-fluid mx-auto d-block" alt="Educator historia">
            </div>
        </div>
    </div>
    <div class="container py-5">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 text-center">
                <h2 class="edu-title">Nuestro equipo</h2>
                <p>Un equipo multi-disciplinar y experto en el área de logística nacional e internacional.</p>
            </div>
        </div>
        <div class="edu-type-job row row-cols-1 justify-content-center pb-md-5">
            <div class="col col-md-3">
                <div class="card edu-card">
                    <div class="card-body text-center">
                      <img src="./img/web/edu-profile01.png" class="w-100 d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Mariola Fajardo</h5>
                      <p class="card-text fw-semibold">Founding Partner</p>
                      <a href="#" class="btn btn-primary btn-lg w-100 edu-btn-blue">
                        <i class="bi bi-linkedin"></i>
                      </a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-3">
                <div class="card edu-card">
                    <div class="card-body text-center">
                        <img src="./img/web/edu-profile02.png" class="w-100 d-block mb-4" alt="Trabajos">
                        <h5 class="card-title edu-title">Kim Goddard</h5>
                        <p class="card-text fw-semibold">Founding Partner</p>
                        <a href="#" class="btn btn-primary btn-lg w-100 edu-btn-blue">
                          <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-3">
                <div class="card edu-card">
                    <div class="card-body text-center">
                        <img src="./img/web/edu-profile03.png" class="w-100 d-block mb-4" alt="Trabajos">
                        <h5 class="card-title edu-title">Jessica Spackman</h5>
                        <p class="card-text fw-semibold">Consultant</p>
                        <a href="#" class="btn btn-primary btn-lg w-100 edu-btn-blue">
                            <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('includes.footerweb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
    </div>
    <script src="../js/web/popper.min.js"></script>
    <script src="../js/web/bootstrap.min.js"></script>
    <script src="../js/web/util.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\postulaciones\resources\views/nosotros/index.blade.php ENDPATH**/ ?>