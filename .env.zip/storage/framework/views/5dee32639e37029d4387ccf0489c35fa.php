	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">           
            <li>
				<a href="<?php echo e(url('/home')); ?>">
					<i class="glyphicon glyphicon-signal"></i>
					<span class="lbl">Dashboard </span>
				</a>
			</li>
	        <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-user"></i>
	                <span class="lbl">Seguridad</span>
	            </span>
	            <ul>
	                <li  >
					<a href="ui-buttons.html">
						
						<span class="lbl">						
						Usuarios</span></a></li>	                
	            </ul>
	        </li>
	        <li class="blue with-sub">
	            <span>
	                <span class="glyphicon glyphicon-cloud"></span>
	                <span class="lbl">Pagina web</span>
	            </span>
	            <ul>
	                <li><a href="email_templates.html"><span class="lbl">Inicio</span></a></li>
	                <li><a href="blank.html"><span class="lbl">Como trabajamos</span></a></li>
	                <li><a href="empty.html"><span class="lbl">Nosotros</span></a></li>
	                <li><a href="prices.html"><span class="lbl">Empleos</span></a></li>
	                <li><a href="typography.html"><span class="lbl">Quiero contratar</span></a></li>
	                <li><a href="sign-in.html"><span class="lbl">Registro</span></a></li>
	                <li><a href="sign-up.html"><span class="lbl">Contacto</span></a></li>
	                
	            </ul>
	        </li>
            <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-cog"></i>
	                <span class="lbl">Configuracion</span>
	            </span>
	            <ul>
	                <li><a href="messenger.html"><span class="lbl">Información General</span></a></li>
	                <li><a href="datatables-net.html"><span class="lbl">Nuestros clientes</span></a></li>                        
                    <li><a href="chat-write.html"><span class="lbl">Equipo</span></a></li>
                    <li><a href="chat-write.html"><span class="lbl">Sectores</span></a></li>
	                <li><a href="chat-index.html"><span class="lbl">Testimonios</span></a></li>

	            </ul>
	        </li>
	        <li class="blue with-sub">
	            <span>
	                <i class="glyphicon glyphicon-gift"></i>
	                <span class="lbl">Catálogos </span>
	            </span>
	            <ul>
	                <li><a href="<?php echo e(url('/modalidades')); ?>"><span class="lbl">Modalidad</span></a></li>
	                <li><a href="<?php echo e(url('/categorias')); ?>"><span class="lbl">Categorias</span></a></li>
	                <li><a href="<?php echo e(url('/paises')); ?>"><span class="lbl">Paises</span></a></li>
	                <li><a href="<?php echo e(url('/cargos')); ?>"><span class="lbl">Cargos</span></a></li>	               
	            </ul>
	        </li>
	        
	      
            <li class="blue with-sub">
                <span>
                    <span class="glyphicon glyphicon-tasks"></span>
	                <span class="lbl">Administración</span>
	            </span>
                    <ul>
                        <a href="<?php echo e(url('/empresas')); ?>"><span class="lbl">Empresas</span></a></li>
                        <a href="<?php echo e(url('/ofertas')); ?>"><span class="lbl">Empleos</span></a></li>     
                        <a href="<?php echo e(url('/candidatos')); ?>"><span class="lbl">Candidatos</span></a></li>   
                        <a href="<?php echo e(url('/solicitudes')); ?>"><span class="lbl">Solicitudes</span></a></li> 
						<a href="bootstrap-datatables.html"><span class="lbl">Contactos</span></a></li>     
                    </ul>	            
	        </li>
	    
	    </ul>
	
	    <section>
	        <header class="side-menu-title">Reportes</header>
	        <ul class="side-menu-list">
	            <li>
	                <a href="#">
	                    <i class="glyphicon glyphicon-edit"></i>
	                    <span class="lbl">Empleos por empresa</span>
	                </a>
	            </li>
	            <li>
	                <a href="#">
	                    <i class="glyphicon glyphicon-list"></i>
	                    <span class="lbl">Cantidatos aprobados</span>
	                </a>
	            </li>
	            <li>
	                <a href="#">
	                    <i class="glyphicon glyphicon-ok-sign"></i>
	                    <span class="lbl">Solicitudes aprobadas / General</span>
	                </a>
	            </li>
	           
	        </ul>
	    </section>
	</nav><!--.side-menu--><?php /**PATH C:\laragon\www\postulaciones\resources\views/includes/menu.blade.php ENDPATH**/ ?>