

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-user"></span> <?php echo e($ofertas->first()->candidato); ?></h5>
                      </div> 
                      <div class="col text-right">
                        <a href="<?php echo e(url('/candidatos')); ?>" class="btn btn-sm btn-default">Regresar
                          <span class="glyphicon glyphicon-chevron-left"></span>
                      </a>                     
                    </div>
                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>                 

                    <div class="table-responsive">
                      <div class="bootstrap-table">                      
                        <table id="table-candidatos" class="table table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th>Empresa</th>                                               
                                <th>Puesto</th>                                 
                                <th>Fecha de publicacion</th>   
                                <th>Fecha aplico</th>                         
                                <th>Estado</th>       
                                <th>Contratado</th>  
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($oferta-> empresa); ?> </td>                                
                                    <td> <?php echo e($oferta-> puesto); ?> </td>                                  
                                    <td> <?php echo e($oferta-> fecha_publicacion); ?> </td>                               
                                    <td> <?php echo e($oferta-> fecha_aplico); ?></td>  
                                    <td> <?php echo e($oferta-> estado); ?></td> 
                                    <td> <?php echo e($oferta-> contratado); ?></td>   
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>     
                      <div class="pull-right pagination">
                        <ul class="pagination">
                          <?php echo e($ofertas->links()); ?>

                        </ul>
                       
                      </div>  
                  </div>
                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/candidatos/ofertas.blade.php ENDPATH**/ ?>