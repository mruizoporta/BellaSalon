

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-book"></span> Nuevao almacen</h5>          
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/almacenes')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
		<div class="box-typical box-typical-padding">
        <form action="<?php echo e(url('/almacenes')); ?>" method="POST">
          <?php echo csrf_field(); ?>            

            <div class="form-group">                
              <label class="form-label" for="nombreempresa">Empresa</label>                
              <select class="form-control" name="empresa_id">
                <option value=""> --Seleccione la empresa--</option>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($empresa -> id); ?>"> <?php echo e($empresa -> nombre); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              </select>
            </div>

            <fieldset class="form-group">
              <label class="form-label" for="name"> Nombre </label>
              <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" require> 
          </fieldset>  

            <button type="submit" class="btn btn-sm btn-success" > Crear almacen</button>
            <br>
            <br>
        </form>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    

    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.caret.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.tag-editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/select2/select2.full.min.js')); ?>"></script>

    <script>
      $(function() {
        $('#tags-editor-textarea').tagEditor();
      });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartd\resources\views/almacenes/create.blade.php ENDPATH**/ ?>