

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-user"></span> <?php echo e($candidatos->first()->puesto); ?></h5>
                      </div> 
                      <div class="col text-right">
                        <a href="<?php echo e(url('/ofertas')); ?>" class="btn btn-sm btn-default">Regresar
                          <span class="glyphicon glyphicon-chevron-left"></span>
                      </a>                     
                    </div>
                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>                 

                    <div class="table-responsive">
                      <div class="bootstrap-table">                      
                        <table id="table-candidatos" class="table table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th>Candidato</th>            
                                <th>Correo electrónico</th>   
                                <th>Teléfono</th>                         
                                <th>Fecha aplico</th>       
                                <th>Contratado</th>
                                <th></th>    
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($candidato-> candidato); ?> </td>                                
                                    <td> <?php echo e($candidato-> correo); ?> </td>                                  
                                    <td> <?php echo e($candidato-> telefono); ?> </td>                               
                                    <td> <?php echo e($candidato-> fecha_aplico); ?></td>  
                                    <td> <?php echo e($candidato-> contratado); ?></td>  
                                    <td>
                                        <a href="<?php echo e(url('/candidatos/'.$candidato->id.'/download')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon glyphicon-download-alt"></span>
                                          </a>
                                          <?php if($candidato->linkedin==''): ?>
                                          <a href="https://www.linkedin.com" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span ><i class="fa fa-linkedin fa-fw"></i></i></span>
                                          </a>
                                          <?php else: ?>
                                          <a href="https://www.linkedin.com/in/<?php echo e($candidato->linkedin); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span ><i class="fa fa-linkedin fa-fw"></i></i></span>
                                          </a>  
                                          <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>     
                      <div class="pull-right pagination">
                        <ul class="pagination">
                          <?php echo e($candidatos->links()); ?>

                        </ul>
                       
                      </div>  
                  </div>
                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/ofertas/candidatos.blade.php ENDPATH**/ ?>