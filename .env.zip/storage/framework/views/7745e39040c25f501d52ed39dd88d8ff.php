<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Inicio | Educator</title>
        <link href="./css/bootstrap.min.css" rel="stylesheet">
        <link href="./css/educator.css" rel="stylesheet">
        <link rel="icon" href="./img/favicon-edu.png"type="image/png">
        <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>

    </head>
    <body >
        <a href="https://api.whatsapp.com/send?phone=+50584368899" class="btn-wsp" target="_blank">
            <i class="fa fa-whatsapp icono"></i>
        </a>

        <!-- Header -->
    <header class="edu-header">
        <div class="px-3 py-2 text-bg-dark border-bottom edu-main-subnav">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start py-2">
                        <ul class="nav me-auto">
                          <li class="nav-item d-none d-md-block">
                            <b>Phone:</b>
                            <a href="tel:+34910062021" class="text-white link-underline link-underline-opacity-0">+34 910 062 021</a>
                            /
                            <a href="tel:+34600276594" class="text-white link-underline link-underline-opacity-0">+34 600 276 594</a>
                          </li>
                          <li class="nav-item d-block d-sm-none px-2">
                            <a href="mailto:info@educators.com"><img src="./img/edu-mail.svg" alt="mail"></a>
                          </li>
                          <li class="nav-item d-none d-sm-block px-2">
                            <b>Email:</b>
                            <a href="mailto:info@educators.com" class="text-white link-underline link-underline-opacity-0">info@educators.com</a>
                          </li>
                          <li class="nav-item">
                            <a href="#" class="text-white px-2">
                                <img src="./img/edu-linkedin.png" alt="Educator"/>
                            </a>
                          </li>
                        </ul>
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/edu-es.png" alt="Educator Español" onclick="idioma(1)"/>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="text-white px-2">
                                    <img src="./img/edu-en.png" alt="Educator Ingles" onclick="idioma(2)"/>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
        </div>
        <div class="navbar navbar-expand-lg px-3 py-2 edu-main-nav">
            <div class="container">
                <a class="navbar-brand" href="/">
                    <img src="./img/logo-educator.png" class="img-fluid" alt="Educator"/>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="nav navbar-nav me-auto mb-2 mb-md-0 edu-main-menu">
                        <li><a href="index.html" class="nav-link px-2 link-secondary">Inicio</a></li>
                        <li><a href="como-trabajamos.html" class="nav-link px-2">Cómo trabajamos</a></li>
                        <li><a href="nosotros.html" class="nav-link px-2">Nosotros</a></li>
                        <li><a href="empleos.html" class="nav-link px-2">Empleos</a></li>
                        <li><a href="contratar.html" class="nav-link px-2">Quiero contratar</a></li>
                        <li><a href="registro.html" class="nav-link px-2">Registro</a></li>
                        <li><a href="contacto.html" class="nav-link px-2">Contacto</a></li>
                    </ul>
                    <div class="text-lg-end">
                        <button type="button" class="btn btn-primary edu-btn-yellow" data-bs-toggle="modal" data-bs-target="#loginModal">Iniciar sesión</button>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Body -->
    <div class="edu-hero px-4 py-5 mb-5 text-white text-center">
        <h1 class="display-6 fw-bold">International Education Recruitment</h1>
        <div class="col col-lg-6 mx-auto">
            <p class="text-white lead mb-4">En Educcators, ofrecemos un servicio especializado en la contratación de personal educativo de todos los niveles</p>
            <p class="text-white lead mb-4">Nos dedicamos a brindar apoyo tanto a aquellos que desean avanzar en su carrera profesional dentro del sector, como a las instituciones que buscan atraer y retener al mejor talento.</p>
            <p class="text-white lead mb-4">¡Únete a Educcators hoy mismo y descubre todas las oportunidades que tenemos para ti!</p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center"> 
            <button type="button" class="btn btn-primary btn-lg px-4 gap-3 edu-btn-yellow">Vacancies</button>
            <button type="button" class="btn btn-outline-secondary btn-lg btn-outline-edu-white px-4">Register</button>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row my-5 g-5 align-items-center">
            <div class="col-md-6 col-lg-6">
                <h2 class="edu-title">Nuestra historia</h2>
                <p>Con más de 20 años de experiencia profesional en entornos internacionales y una sólida trayectoria en el sector educativo, contamos con amplia experiencia trabajando en colegios internacionales, universidades e instituciones de posgrado. Esto nos ha brindado una perspectiva única y una comprensión profunda del ámbito educativo.</p>
                <p>Durante nuestra carrera, hemos colaborado con profesionales de primer nivel, lo que nos ha permitido cultivar una amplia red de expertos a nivel global. Nuestro objetivo es aprovechar esta experiencia para brindar apoyo y valiosa información a nuestros clientes y socios que trabajan en la industria de la educación.</p>
            </div>
            <div class="col-md-6 col-lg-6">
                <img src="./img/edul-history.png" class="img-fluid mx-auto d-block" alt="Educator historia">
            </div>
        </div>
    </div>
    <div class="edu-features py-5">
        <div class="container">
            <div class="row g-5 text-center">
                <div class="col-sm-12">
                    <h2 class="text-white">Sectores especializados</h2>
                    <p class="text-white pb-5">Trabajamos en colaboración con diversos sectores especializados.</p>
                </div>
            </div>
            <div class="row row-cols-1 g-5 justify-content-center text-center">
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-schools d-block m-auto"></div>
                        <h6 class="my-3">Schools</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-primary_schools d-block m-auto"></div>
                        <h6 class="my-3">Early Childhood & Primary School</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-u d-block m-auto"></div>
                        <h6 class="my-3">University & Colleges</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-h-edu d-block m-auto"></div>
                        <h6 class="my-3">Higher Education</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-business d-block m-auto"></div>
                        <h6 class="my-3">Business Languages Coach</h6>
                    </div>
                </div>
                <div class="col col-md-3 col-lg-2 text-white">
                    <div class="edu-content-ico-sector p-3">
                        <div class="ico-edu-speaker d-block m-auto"></div>
                        <h6 class="my-3">Speakers</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container py-5">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12">
                <h2 class="edu-title text-center">Cómo trabajamos</h2>
            </div>
        </div>
        <div class="edu-type-job row row-cols-1 justify-content-center pb-md-5">
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                      <img src="./img/icon-enfoque.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Nuestro Enfoque</h5>
                      <p class="card-text">Contamos con una amplia experiencia en la búsqueda de personal en todos los sectores de la educación.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/icon-expe.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Experiencia y especialización</h5>
                      <p class="card-text">Nos avalan años de experiencia trabajando y asesorando a profesionales de la enseñanza.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/icon-candidato.png" class="img-fluid d-block mb-4" alt="Trabajos">
                        <h5 class="card-title edu-title">Encuentra al candidato idóneo</h5>
                        <p class="card-text">Todos nuestros candidatos son cuidadosamente examinados y asignados a las ofertas.</p>
                        <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="edu-type-job row row-cols-1 justify-content-center">
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/icon-necesidad.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Nos adaptamos a tus necesidades</h5>
                      <p class="card-text">Ofrecemos una amplia variedad de opciones para satisfacer a nuestros clientes</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
            <div class="col col-md-4">
                <div class="card edu-card">
                    <div class="card-body">
                        <img src="./img/icon-presupuesto.png" class="img-fluid d-block mb-4" alt="Trabajos">
                      <h5 class="card-title edu-title">Diseñamos presupuestos a la medida de tus exigencias.</h5>
                      <p class="card-text">Entendemos que el presupuesto es un factor importante para cualquier organización.</p>
                      <a href="#" class="btn btn-primary btn-outline-edu-yellow">Leer más</a>
                    </div>
                  </div>
            </div>
        </div>
    </div>
    <div class="edu-clientes py-5">
        <div class="container">
            <div class="row g-5 text-center mb-4">
                <div class="col">
                    <h2 class="edu-title">Nuestros clientes</h2>
                    <p>Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                </div>
            </div>
            <div class="row row-cols-2 row-cols-sm-6 g-5 text-center justify-content-center align-items-center">
                <div class="col">
                    <img src="./img/LOGO-UNIVERSITY.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/IE_Business_School_logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/logo-aleman-collage.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/xPAC-logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
                <div class="col">
                    <img src="./img/Esade_logo.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                </div>
            </div>
        </div>
    </div>
    <div class="edu-testimonial">
        <div id="carouselTestimonialEdu" class="carousel slide">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="./img/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./img/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./img/edu-bg-slider.png" class="d-block w-100" alt="slider">
                <div class="carousel-caption">
                    <h3>Testimonios</h3>
                    <p class="text-white">Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.Trabajamos con una amplia gama de áreas profesionales y alcance geográfico, desde la educación primaria hasta la educación de posgrado.</p>
                    <img src="./img/edu-star.png" class="img-fluid mx-auto d-block" alt="logo-cliente"/>
                    <h5 class="mt-4">Joaquin Sanz Berrioategortua</h5>
                    <small>Kereon Partners Venture Capital – CEO. Director Académico del PMD. ESADE.</small>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselTestimonialEdu" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselTestimonialEdu" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
    </div>

    <!-- Footer -->
    <div class="edu-footer">
        <div class="container">
            <footer class="row row-cols-2 row-cols-sm-4 row-cols-md-5 py-5">
                <div class="col-12 col-sm-3 col-md-4 col-lg mb-3">
                    <a href="/" class="d-flex align-items-center mb-4 link-body-emphasis text-decoration-none">
                        <img src="./img/logo-educator-footer.png" alt="Educator"/>
                    </a>
                    <button type="button" class="btn btn-primary btn-sm px-4 gap-3 edu-btn-yellow">Aplicar ya</button>
                </div>
                <div class="col d-none d-lg-block mb-3"></div>
                <div class="col col-sm-3 col-md-3 col-lg mb-3">
                   <b>Email</b>
                   <p>info@educcators.com</p>
                   <b>Email</b>
                   <p>+34 910 062 021
                    <br/>
                    +34 600 276 594</p>
                    <b>WhatsApp</b>
                   <p>+34 910 062 021
                    <br/>
                    +34 600 276 594</p>
                </div>
            
                <div class="col col-sm-3 col-md-3 col-lg mb-3">
                    <h6>EMPLEOS</h6>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary"><img src="./img/icon-arrow-career.png" class="d-inline-block px-2" alt="icon career">Career Job 01</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary"><img src="./img/icon-arrow-career.png" class="d-inline-block px-2" alt="icon career">Career Job 02</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary"><img src="./img/icon-arrow-career.png" class="d-inline-block px-2" alt="icon career">Career Job 03</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary"><img src="./img/icon-arrow-career.png" class="d-inline-block px-2" alt="icon career">Career Job 04</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary"><img src="./img/icon-arrow-career.png" class="d-inline-block px-2" alt="icon career">Career Job 05</a></li>
                    </ul>
                </div>
            
                <div class="col col-sm-3 col-md-2 col-lg mb-3">
                    <ul class="nav flex-column edu-menu-footer">
                        <li class="nav-item mb-2"><a href="index.html" class="nav-link p-0 text-body-secondary">Inicio</a></li>
                        <li class="nav-item mb-2"><a href="como-trabajamos.html" class="nav-link p-0 text-body-secondary">Servicios</a></li>
                        <li class="nav-item mb-2"><a href="nosotros.html" class="nav-link p-0 text-body-secondary">Nosotros</a></li>
                        <li class="nav-item mb-2"><a href="empleos.html" class="nav-link p-0 text-body-secondary">Empleos</a></li>
                        <li class="nav-item mb-2"><a href="contratar.html" class="nav-link p-0 text-body-secondary">Quiero contratar</a></li>
                        <li class="nav-item mb-2"><a href="registro.html" class="nav-link p-0 text-body-secondary">Registro</a></li>
                        <li class="nav-item mb-2"><a href="contacto.html" class="nav-link p-0 text-body-secondary">Contacto</a></li>
                        <li class="nav-item mb-2"><a href="#" class="text-white p-0"><img src="./img/edu-linkedin-y.png" alt="Educator"/></a></li>
                    </ul>
                </div>
            </footer>
        </div>
    </div>
    <!-- MODAL -->
    <div class="modal edu-modal fade" id="loginModal" tabindex="-1" aria-labelledby="eduModaLogin" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered ">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h4 class="text-center edu-title">¿Ya eres usuario?</h4>
                    <form class="row g-3 edu-form">
                        <div class="edu-form-input col-md-6">
                            <label for="loginEmail" class="form-label">Correo electrónico</label>
                            <input type="email" class="form-control" id="loginEmail">
                        </div>
                        <div class="edu-form-input col-md-6">
                            <label for="inputPassword" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="inputPassword">
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-100 edu-btn-yellow">Iniciar sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="./js/popper.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/util.js"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\postulaciones\resources\views/welcome.blade.php ENDPATH**/ ?>