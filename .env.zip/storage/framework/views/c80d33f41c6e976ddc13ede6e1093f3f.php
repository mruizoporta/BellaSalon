

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-user"></span> Solicitudes</h5>
                      </div>                     
                    </div>

                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>                 

                    <div class="table-responsive">
                      <div class="bootstrap-table">
                        <div class="fixed-table-toolbar">
                          <div class="pull-left search">
                            <form action="">
                              <div class="form-row">
                                <input type="text" class="form-control" placeholder="Buscar..." name="texto" value=<?php echo e($texto); ?>>
                              </div>
                            </form>
                          </div>
                        </div>
                        <table id="table-candidatos" class="table table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th width="1">
                                    #
                                </th>                                               
                                <th>Empresa</th> 
                                <th>Puesta de trabajo</th>  
                                <th>Nombre contacto</th>    
                                <th>Correo electrónico</th>                            
                                <th>Fecha de solicitud</th>                      
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($solicitud-> id); ?> </td>                                
                                    <td> <?php echo e($solicitud-> empresa); ?> </td>
                                    <td> <?php echo e($solicitud-> puesto_trabajo); ?> </td>
                                    <td> <?php echo e($solicitud-> nombrecompleto); ?> </td>  
                                    <td> <?php echo e($solicitud-> correo); ?> </td>  
                                    <td> <?php echo e($solicitud-> fecha_solicitud); ?> </td>  
                                   <td>
                                        <form action="<?php echo e(url('/solicitudes/'.$solicitud->id.'/inactivar')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>    
                                          <a href="<?php echo e(url('/solicitudes/'.$solicitud->id.'/view')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-eye-open"></span>
                                          </a>                                        
                                          <button type="submit" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                          </button>
                                          <a href="<?php echo e(url('/candidatos/'.$solicitud->id.'/download')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon glyphicon-download-alt"></span>
                                          </a>                                       
                                        </form>
                                      
                                      </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>     
                      <div class="pull-right pagination">
                        <ul class="pagination">
                          <?php echo e($solicitudes->links()); ?>

                        </ul>
                       
                      </div>  
                  </div>
                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/solicitudes/index.blade.php ENDPATH**/ ?>