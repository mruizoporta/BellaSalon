

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-book"></span> Agregar empleo</h5>          
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/ofertas')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

	
    <div class="box-typical box-typical-padding">
      <form action="<?php echo e(url('/ofertas/'.$oferta->id)); ?>" method="POST"> 
          <?php echo csrf_field(); ?>  
          <?php echo method_field('PUT'); ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">  
                <fieldset class="form-group">                
                  <label class="form-label" for="nombrepais">Pais</label>
                  <select class="form-control" name="paises_id">
                    <option value=""> --Seleccione el pais--</option>
                    <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pais -> id); ?>"
                      <?php if($pais->id === $oferta->paises_id): ?>
                      selected
                      <?php endif; ?>
                      > <?php echo e($pais -> nombre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </select>
              </fieldset>

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">                
                <fieldset class="form-group">                
                    <label class="form-label" for="nombreempresa">Empresa</label>
                    <select class="form-control" name="empresas_id">
                      <option value=""> --Seleccione la empresa--</option>
                      <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($empresa -> id); ?>"
                        <?php if($empresa->id === $oferta->empresas_id): ?>
                        selected
                        <?php endif; ?>
                        > <?php echo e($empresa -> nombre); ?> </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>
                </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div>  

          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">   
                <fieldset class="form-group ">
                  <label class="form-label" for="lblnombre"> Nombre del puesto (Es) </label>
                  <input type="text" name="nombre" class="form-control" value="<?php echo e($oferta->nombre); ?>" require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">
                <fieldset class="form-group ">
                  <label class="form-label" for="lblnombre_en"> Nombre del puesto (En)</label>
                  <input type="text" name="nombre_en" class="form-control" value="<?php echo e($oferta->nombre_en); ?>"  require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div> 
          
          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">   
                <fieldset class="form-group ">
                  <label class="form-label" for="lblnombrecompleto"> Nombre completo del puesto (Es) </label>
                  <input type="text" name="nombrecompleto" class="form-control" value="<?php echo e($oferta->nombrecompleto); ?>" require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">
                <fieldset class="form-group ">
                  <label class="form-label" for="lblnombrecompleto_en"> Nombre completo del puesto (En)</label>
                  <input type="text" name="nombrecompleto_en" class="form-control" value="<?php echo e($oferta->nombrecompleto_en); ?>"  require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div>   
          
          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">   
                <fieldset class="form-group ">
                  <label class="form-label" for="lblarea"> Área (Es) </label>
                  <input type="text" name="area" class="form-control" value="<?php echo e($oferta->area); ?>" require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">
                <fieldset class="form-group ">
                  <label class="form-label" for="lblarea_en">Área (En)</label>
                  <input type="text" name="area_en" class="form-control" value="<?php echo e($oferta->area_en); ?>" require> </input>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div>      

          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">  
                <fieldset class="form-group">                
                  <label class="form-label" for="nombremodalidad">Modalidad</label>
                  <select class="form-control" name="modalidades_id">
                    <option value=""> --Seleccione la modalidad--</option>
                    <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($modalidad -> id); ?>"
                      <?php if($modalidad->id === $oferta->modalidades_id): ?>
                      selected
                      <?php endif; ?>
                      > <?php echo e($modalidad -> nombre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </select>
              </fieldset>

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">                
                <fieldset class="form-group">                
                    <label class="form-label" for="lblnombrecategoria">Categoría</label>
                    <select class="form-control" name="categorias_id">
                      <option value=""> --Seleccione la categoría--</option>
                      <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($categoria -> id); ?>"
                        <?php if($categoria->id === $oferta->categorias_id): ?>
                        selected
                        <?php endif; ?>
                        > <?php echo e($categoria -> nombre); ?> </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>
                </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div>  
       
          <div class="row">
            <div class="col-lg-6">
              <div class="input-group">   
                <fieldset class="form-group ">
                  <label class="form-label" for="lblresumenpuesto"> Resumen del puesto (Es) </label>
                  <textarea rows="5"  name="resumenpuesto"  class="form-control">  <?php echo e($oferta->resumenpuesto); ?></textarea>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
              <div class="input-group">
                <fieldset class="form-group ">
                  <label class="form-label" for="lblresumenpuesto_en"> Resumen del puesto (En)</label>
                  <textarea rows="5"  name="resumenpuesto_en"  class="form-control">  <?php echo e($oferta->resumenpuesto_en); ?> </textarea>
                </fieldset>
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div> 

          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lbldeberesesenciales"> Deberes esenciales: (Es) </label>
                  <textarea class="summernote" name="deberesesenciales"><?php echo e($oferta->deberesesenciales); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lbldeberesesenciales_en"> Deberes esenciales: (En) </label>
                  <textarea class="summernote" name="deberesesenciales_en"><?php echo e($oferta->deberesesenciales_en); ?></textarea></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>

          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lbldeberessecundarios"> Deberes secundarios: (Es) </label>
                  <textarea class="summernote" name="deberessecundarios"><?php echo e($oferta->deberessecundarios); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lbldeberessecundarios_en"> Deberes secundarios: (En) </label>
                  <textarea class="summernote" name="deberessecundarios_en"><?php echo e($oferta->deberessecundarios_en); ?></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>
          
          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lblhoraslaborales"> Horas Laborales: (Es) </label>
                  <textarea class="summernote" name="horaslaborales" ><?php echo e($oferta->horaslaborales); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lblhoraslaborales_en">Horas Laborales: (En) </label>
                  <textarea class="summernote" name="horaslaborales_en"><?php echo e($oferta->horaslaborales_en); ?></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>
          
          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lbleducacion"> Educación: (Es) </label>
                  <textarea class="summernote" name="educacion"><?php echo e($oferta->educacion); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lbleducacion_en">Educación: (En) </label>
                  <textarea class="summernote" name="educacion_en"><?php echo e($oferta->educacion_en); ?></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>

          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lblexperiencia"> Experiencia: (Es) </label>
                  <textarea class="summernote" name="experiencia"><?php echo e($oferta->experiencia); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lblexperiencia_en">Experiencia: (En) </label>
                  <textarea class="summernote" name="experiencia_en"><?php echo e($oferta->experiencia_en); ?></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>
          
          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <label class="form-label" for="lbllicenciacertificaciones"> Licencia(s)/Certificación (Es): </label>
                  <textarea class="summernote" name="licenciacertificaciones"><?php echo e($oferta->licenciacertificaciones); ?></textarea>                    
                </fieldset>

                <fieldset class="form-group ">
                  <label class="form-label" for="lbllicenciacertificaciones_en">Licencia(s)/Certificación (En): </label>
                  <textarea class="summernote" name="licenciacertificaciones_en"><?php echo e($oferta->licenciacertificaciones_en); ?></textarea>                    
                </fieldset>      

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>

          <div class="row">
            <div class="col-lg-12">
              <div class="input-group">  

                <fieldset class="form-group ">
                  <button type="submit" class="btn btn-sm btn-success" > Guardar cambios</button>
                  
                </fieldset>    

              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->    
          </div>

           
            <br>
            <br>
        </form>
        </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.caret.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.tag-editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
	  <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	  <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	  <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

    <script src="<?php echo e(asset('js/lib/select2/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/summernote/summernote.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('.summernote').summernote({ height: 150});
		});
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/ofertas/edit.blade.php ENDPATH**/ ?>