<?php $__env->startSection('content'); ?>
<div class="row">	  
    
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

             
            </div>
        </div>
    </div>

    <div class="col-xl-6">
        <div class="row">
            <div class="col-sm-6">
                <article class="statistic-box red">
                    <div>
                        <div class="number">26</div>
                        <div class="caption"><div>Ordenes de trabajo/ Mes actual</div></div>	                                
                    </div>
                </article>
            </div><!--.col-->
            <div class="col-sm-6">
                <article class="statistic-box yellow">
                    <div>
                        <div class="number">12</div>
                        <div class="caption"><div>Facturas / Mes actual</div></div>
                        
                    </div>
                </article>
            </div><!--.col-->
            <div class="col-sm-6">
                <article class="statistic-box red">
                    <div>
                        <div class="number">104</div>
                        <div class="caption"><div>Cuentas por pagar / Mes actual</div></div>
                        
                    </div>
                </article>
            </div><!--.col-->
            <div class="col-sm-6">
                <article class="statistic-box yellow">
                    <div>
                        <div class="number">29</div>
                        <div class="caption"><div>Cuentas por cobrar / Mes actual</div></div>	                               
                    </div>
                </article>
            </div><!--.col-->
        </div><!--.row-->
    </div><!--.col-->
</div><!--.row-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BellaSalon\resources\views/home.blade.php ENDPATH**/ ?>