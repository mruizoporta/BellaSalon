

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-home"></span> Existencia de productos</h5>
                      </div>                     
                    </div>
                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                  <div class="table-responsive">
                    <table id="table-productos" class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th width="1">
                                #
                            </th>
                            <th>Almacen</th>
                            <th>Producto</th>                             
                            <th>Marca</th>  
                            <th>Existencia</th>  
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bodegaproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodegaproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td> <?php echo e($bodegaproducto-> id); ?> </td>                              
                                <td> <?php echo e($bodegaproducto-> almacen->nombre); ?> </td>
                                <td> <?php echo e($bodegaproducto-> producto->nombre); ?> </td>
                                <td> <?php echo e($bodegaproducto-> producto->marca->nombre); ?> </td>
                                <td> <?php echo e($bodegaproducto-> existencia); ?> </td>                               
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>      
                </div>
            </div>
        </div>
    </div>

    
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartd\resources\views/existencias/index.blade.php ENDPATH**/ ?>