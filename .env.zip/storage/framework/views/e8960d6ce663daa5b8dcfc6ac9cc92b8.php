

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header ">
      <div class="row align-items-center">
        <div class="col">
          <h5 class="mb-0">
            <span class="glyphicon glyphicon-book"></span> Nuevo producto</h5>          
        </div>
        <div class="col text-right">
          <a href="<?php echo e(url('/productos')); ?>" class="btn btn-sm btn-default">Regresar
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
       
        </div>
      </div>
    </div>
    
    <div class="card-body">
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger" role="alert">
        <i class="fas fa-exclamation-triangle"></i>
      <strong>Por favor!</strong> <?php echo e($error); ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
		<div class="box-typical box-typical-padding">
        <form action="<?php echo e(url('/productos')); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <div class="row">
       
              <div class="col-lg-12">
                <div class="input-group"> 
                  <fieldset class="form-group">
                      <label class="form-label" for="name"> Nombre </label>
                      <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" require> 
                  </fieldset>
                </div><!-- /input-group -->
              </div><!-- /.col-lg-6 -->
          </div>

          <div class="row">

            <div class="col-lg-6">
              <div class="input-group"> 
                <fieldset class="form-group">
                  <label class="form-label" for="name"> Codigo </label>
                  <input type="text" name="codigo" class="form-control" value="<?php echo e(old('codigo')); ?>" require> 
                </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
       
            <div class="col-lg-6">
              <div class="input-group">  
                <div class="form-group">                
                  <label class="form-label" for="nombrecategoria">Categorias</label>                
                  <select class="form-control" name="categoria_id">
                    <option value=""> --Seleccione la categoria--</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria -> id); ?>"> <?php echo e($categoria -> nombre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </select>
                </div>         
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
          </div>

          <div class="row">        

            <div class="col-lg-6">
              <div class="input-group">  
                <div class="form-group">                
                  <label class="form-label" for="nombremarca">Marca</label>                
                  <select class="form-control" name="marca_id">
                    <option value=""> --Seleccione la marca--</option>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($marca -> id); ?>"> <?php echo e($marca -> nombre); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </select>
                </div>                     
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->

          <div class="col-lg-6">
            <div class="input-group">  
              <div class="form-group">                
                <label class="form-label" for="nombremedida">Unidad de medida</label>                
                <select class="form-control" name="medida_id">
                  <option value=""> --Seleccione la unidad de medida--</option>
                  <?php $__currentLoopData = $medidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($medida -> id); ?>"> <?php echo e($medida -> nombre); ?> </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </select>
              </div>     
          </div><!-- /input-group -->
        </div><!-- /.col-lg-6 -->

      </div>  

          <div class="row">           

          <div class="col-lg-6">
            <div class="input-group">  
              <div class="form-group"> 
                <fieldset class="form-group">
                  <label class="form-label" for="lblcostopromedio">Costo</label>             
                  <input type="number" name="costopromedio" class="form-control" value="<?php echo e(old('costopromedio')); ?>" require> 
                </fieldset>               
              </div>         
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->

          <div class="col-lg-6">
            <div class="input-group">  
                <fieldset class="form-group">
                  <label class="form-label" for="lblpreciocredito">Precio credito</label>             
                  <input type="number" name="preciocredito" class="form-control" value="<?php echo e(old('preciocredito')); ?>" require>
                </fieldset>
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->

        </div> 

        <div class="row">
         
          <div class="col-lg-6">
            <div class="input-group">  
              <fieldset class="form-group">
                <label class="form-label" for="lblpreciocontado">Precio contado</label>
                <input type="number" class="form-control" name="preciocontado"  value="<?php echo e(old('preciocontado')); ?>">
              </fieldset>
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->

          <div class="col-lg-6">
            <div class="input-group">  
              <fieldset class="form-group">
                <label for="lblmargenutilidadcredito"> Margen utilidad credito </label>
                <input type="text" name="margenutilidadcredito" class="form-control"  value="<?php echo e(old('margenutilidadcredito')); ?>">
              </fieldset>
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->
        </div> 
       
        <div class="row">         

          <div class="col-lg-6">
            <div class="input-group">  
              <fieldset class="form-group">
                <label for="lblmargenutilidadcontado"> Margen utilidad contado </label>
                <input type="text" name="margenutilidadcontado" class="form-control"  value="<?php echo e(old('margenutilidadcontado')); ?>">
              </fieldset>
            </div><!-- /input-group -->
          </div><!-- /.col-lg-6 -->

          <div class="col-lg-6">
            <div class="input-group">  
              <fieldset class="form-group">
                <label for="cantidadminima"> Cantidad minima </label>
                <input type="text" name="cantidadminima" class="form-control"  value="<?php echo e(old('cantidadminima')); ?>">
              </fieldset>
              </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->

        </div> 

      
            <button type="submit" class="btn btn-sm btn-success" > Crear producto</button>
            <br>
            <br>
        </form>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    

    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.caret.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/jquery-tag-editor/jquery.tag-editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lib/select2/select2.full.min.js')); ?>"></script>

    <script>
      $(function() {
        $('#tags-editor-textarea').tagEditor();
      });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartd\resources\views/productos/create.blade.php ENDPATH**/ ?>