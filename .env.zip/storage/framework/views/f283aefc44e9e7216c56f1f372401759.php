

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header ">
                    <div class="row align-items-center">
                      <div class="col">                        
                        <h5 class="mb-0">
                            <span class="glyphicon glyphicon-briefcase"></span> Empleos</h5>
                      </div>
                      <div class="col text-right">
                        <a href="<?php echo e(url('/ofertas/create')); ?>" class="btn btn-sm btn-primary edu-btn-yellow " >Nuevo empleo</a>
                      </div>
                    </div>

                  </div>
            </div>
                <div class="card-body">
                    <?php if(session('notification')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('notification')); ?>

                    </div>
                    <?php endif; ?>
                </div>                 

                    <div class="table-responsive">
                      <div class="bootstrap-table">
                        <div class="fixed-table-toolbar">
                          <div class="pull-left search">
                            <form action="">
                              <div class="form-row">
                                <input type="text" class="form-control" placeholder="Buscar..." name="texto" value=<?php echo e($texto); ?>>
                              </div>
                            </form>
                          </div>
                        </div>
                        <table id="table-ofertas" class="table table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th width="1">
                                    #
                                </th>   
                                <th>Empresa</th>                                             
                                <th>Nombre del puesto</th>                                 
                                <th>Modalidad</th>                                
                                <th>Estado</th>                                     
                                <th>Candidatos</th>  
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($oferta-> id); ?> </td>   
                                    <td> <?php echo e($oferta-> empresa); ?> </td>                             
                                    <td> <?php echo e($oferta-> nombre); ?> </td>                                    
                                    <td> <?php echo e($oferta-> modalidad); ?> </td> 
                                    <td> <?php echo e($oferta-> estado); ?> </td>                               
                                    <td style="text-align:center"> <a href="<?php echo e(url('/ofertas/'.$oferta->id.'/ofertas')); ?>"><?php echo e($oferta-> candidatos); ?> </a></td>                             
                                    <td>
                                        <form action="<?php echo e(url('/ofertas/'.$oferta->id.'/inactivar')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>    
                                          <a href="<?php echo e(url('/ofertas/'.$oferta->id.'/edit')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-pencil"></span>
                                          </a>
                                        
                                          <button type="submit" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon-trash"></span>
                                          </button>

                                          <a href="<?php echo e(url('/ofertas/'.$oferta->id.'/publicar')); ?>" class="tabledit-edit-button btn btn-sm btn-default">
                                            <span class="glyphicon glyphicon glyphicon-thumbs-up"></span>
                                          </a>
                                         
                                        </form>
                                      
                                      </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>     
                      <div class="pull-right pagination">
                        <ul class="pagination">
                          <?php echo e($ofertas->links()); ?>

                        </ul>
                       
                      </div>  
                  </div>
                </div>
            </div>
        </div>
    </div>
  </div>


  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postulaciones\resources\views/ofertas/index.blade.php ENDPATH**/ ?>